import { useCallback, useEffect, useState } from "react";
import "./MainWindow.css";
import VoiceRoom from "./VoiceRoom";
import FeaturePanel from "./FeaturePanel";

const API = (import.meta.env.VITE_API_URL || "http://127.0.0.1:8000").replace(/\/+$/, "");

type AnyRecord = {
  id: number;
  [key: string]: any;
};

type Community = AnyRecord & {
  name: string;
  description?: string;
  member_count?: number;
};

type Channel = AnyRecord & {
  name: string;
  channel_type?: string;
  visibility?: "public" | "private";
};

type Message = AnyRecord & {
  content: string;
  user_id?: number;
  username?: string;
  created_at?: string;
};

type ProfileData = {
  display_name: string;
  bio: string;
  avatar_url: string;
  status: "online" | "away" | "busy" | "offline";
};

type FriendItem = {
  id: number;
  username: string;
  display_name?: string;
  avatar_url?: string;
  status?: string;
  request_id?: number;
};

type FriendsResponse = {
  friends: FriendItem[];
  incoming: FriendItem[];
  outgoing: FriendItem[];
};

async function apiRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set("Accept", "application/json");

  if (options.body) headers.set("Content-Type", "application/json");

  const token = localStorage.getItem("comind_access_token");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let response: Response;
  try {
    response = await fetch(`${API}${path}`, { ...options, headers });
  } catch {
    throw new Error("Backend недоступен. Запусти сервер COMIND на порту 8000.");
  }

  const data = response.status === 204 ? null : await response.json().catch(() => ({}));

  if (!response.ok) {
    const detail = (data as any)?.detail;
    const message = Array.isArray(detail)
      ? detail.map((x: any) => x.msg || "").join("; ")
      : detail;
    throw new Error(message || `Ошибка HTTP ${response.status}`);
  }

  return data as T;
}

function asArray<T>(value: any): T[] {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.results)) return value.results;
  return [];
}

export default function MainWindow({
  username,
  userId,
  userIsAdmin = false,
  onLogout,
}: {
  username: string;
  userId?: number;
  userIsAdmin?: boolean;
  onLogout: () => void;
}) {
  const [communities, setCommunities] = useState<Community[]>([]);
  const [community, setCommunity] = useState<Community | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [channel, setChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState("");
  const [search, setSearch] = useState("");
  const [communityName, setCommunityName] = useState("");
  const [communityDescription, setCommunityDescription] = useState("");
  const [channelName, setChannelName] = useState("");
  const [profile, setProfile] = useState<ProfileData>({
    display_name: "", bio: "", avatar_url: "", status: "online",
  });
  const [profileDraft, setProfileDraft] = useState<ProfileData>({
    display_name: "", bio: "", avatar_url: "", status: "online",
  });
  const [showProfileEditor, setShowProfileEditor] = useState(false);
  const [profileSaving, setProfileSaving] = useState(false);
  const [showFriendsPanel, setShowFriendsPanel] = useState(false);
  const [friends, setFriends] = useState<FriendItem[]>([]);
  const [incomingFriends, setIncomingFriends] = useState<FriendItem[]>([]);
  const [outgoingFriends, setOutgoingFriends] = useState<FriendItem[]>([]);
  const [friendUsername, setFriendUsername] = useState("");
  const [friendsLoading, setFriendsLoading] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<number | null>(null);
  const [editDraft, setEditDraft] = useState("");
  const [channelVisibility, setChannelVisibility] = useState<"public" | "private">("public");
  const [showCreateCommunity, setShowCreateCommunity] = useState(false);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const [noticeError, setNoticeError] = useState(false);

  const notify = (text: string, isError = false) => {
    setNotice(text);
    setNoticeError(isError);
  };
  const loadProfile = useCallback(async () => {
    try {
      const data = await apiRequest<ProfileData>("/api/profile/me");
      setProfile({
        display_name: data.display_name || "",
        bio: data.bio || "",
        avatar_url: data.avatar_url || "",
        status: data.status || "online",
      });
    } catch (error) {
      console.warn("Profile synchronization failed:", error);
    }
  }, []);



  const loadCommunities = useCallback(async () => {
    try {
      const result = await apiRequest<any>("/api/communities/");
      setCommunities(asArray<Community>(result));
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось загрузить сообщества", true);
    }
  }, []);

  const loadChannels = useCallback(async (selected: Community) => {
    setNotice("");
    try {
      const result = await apiRequest<any>(
        `/api/communities/${selected.id}/channels`,
      );
      const items = asArray<Channel>(result);

      // Меняем экран только после успешной проверки доступа.
      setCommunity(selected);
      setChannels(items);
      setChannel(items[0] ?? null);
      setMessages([]);

      if (!items.length) {
        notify("Ты вступил в сообщество, но в нём пока нет каналов.");
      }
      return true;
    } catch (error) {
      notify(
        error instanceof Error ? error.message : "Не удалось загрузить каналы",
        true,
      );
      return false;
    }
  }, []);

  // PROFILE_LOAD_EFFECT_V1
  useEffect(() => {
    let active = true;
    apiRequest<ProfileData>("/api/profile/me")
      .then((data) => {
        if (!active) return;
        const normalized: ProfileData = {
          display_name: data.display_name || "",
          bio: data.bio || "",
          avatar_url: data.avatar_url || "",
          status: data.status || "online",
        };
        setProfile(normalized);
        setProfileDraft(normalized);
      })
      .catch((error) => {
        if (active) notify(error instanceof Error ? error.message : "Не удалось загрузить профиль", true);
      });
    return () => { active = false; };
  }, []);

  const [showFeaturePanel, setShowFeaturePanel] = useState(false);
  useEffect(() => {
    void loadProfile();
    const timer = window.setInterval(() => void loadProfile(), 10000);
    return () => window.clearInterval(timer);
  }, [loadProfile]);

  useEffect(() => {
    if (!showFriendsPanel) return;
    const timer = window.setInterval(() => void loadFriends(), 10000);
    return () => window.clearInterval(timer);
  }, [showFriendsPanel]);

  useEffect(() => {
    void loadCommunities();
  }, [loadCommunities]);

  useEffect(() => {
    if (!channel || channel.channel_type === "voice") {
      setMessages([]);
      return;
    }

    let active = true;

    const loadMessages = async () => {
      try {
        const result = await apiRequest<any>(
          `/api/channels/${channel.id}/messages?limit=100`,
        );
        if (active) setMessages(asArray<Message>(result));
      } catch (error) {
        if (active) {
          setMessages([]);
          notify(error instanceof Error ? error.message : "Не удалось загрузить сообщения", true);
        }
      }
    };

    void loadMessages();
    const interval = window.setInterval(() => void loadMessages(), 5000);

    return () => {
      active = false;
      window.clearInterval(interval);
    };
  }, [channel]);

  // MESSAGE_STATUS_SYNC_V2
  useEffect(() => {
    if (!channel || channel.channel_type === "voice") return;
    let active = true;

    const refresh = async () => {
      try {
        const result = await apiRequest<any>(
          `/api/channels/${channel.id}/messages?limit=100`
        );
        if (active) setMessages(asArray<Message>(result));
      } catch {
        // Сохраняем последний успешно загруженный список.
      }
    };

    const timer = window.setInterval(() => void refresh(), 10000);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [channel?.id]);

  async function chooseCommunity(item: Community) {
    await joinCommunity(item);
  }

  async function joinCommunity(item: Community) {
    if (loading) return;

    setLoading(true);
    setNotice("");

    try {
      await apiRequest(`/api/communities/${item.id}/join`, {
        method: "POST",
      });

      const opened = await loadChannels(item);
      await loadCommunities();

      if (opened) {
        notify(`Ты вступил в «${item.name}».`);
      }
    } catch (error) {
      notify(
        error instanceof Error ? error.message : "Не удалось вступить",
        true,
      );
    } finally {
      setLoading(false);
    }
  }

  async function createCommunity(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!communityName.trim()) return;

    setLoading(true);
    try {
      const created = await apiRequest<Community>("/api/communities/", {
        method: "POST",
        body: JSON.stringify({
          name: communityName.trim(),
          description: communityDescription.trim(),
        }),
      });

      setShowCreateCommunity(false);
      setCommunityName("");
      setCommunityDescription("");
      await loadCommunities();
      notify("Сообщество создано.");
      if (created?.id) await loadChannels(created);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось создать сообщество", true);
    } finally {
      setLoading(false);
    }
  }

  async function createChannel(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!community || !channelName.trim()) return;

    setLoading(true);
    try {
      await apiRequest(`/api/communities/${community.id}/channels`, {
        method: "POST",
        body: JSON.stringify({ name: channelName.trim(), visibility: channelVisibility }),
      });
      setChannelName("");
      setChannelVisibility("public");
      setShowCreateChannel(false);
      const updated = await apiRequest<any>(
        `/api/communities/${community.id}/channels`,
      );
      const items = asArray<Channel>(updated);
      setChannels(items);
      if (items.length) setChannel(items[items.length - 1]);
      notify("Канал создан.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось создать канал", true);
    } finally {
      setLoading(false);
    }
  }

  async function sendMessage(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!channel || !messageText.trim()) return;

    const content = messageText.trim();
    setMessageText("");

    try {
      const sent = await apiRequest<Message>(
        `/api/channels/${channel.id}/messages`,
        {
          method: "POST",
          body: JSON.stringify({ content }),
        },
      );
      setMessages((previous) => [...previous, sent]);
    } catch (error) {
      setMessageText(content);
      notify(error instanceof Error ? error.message : "Сообщение не отправлено", true);
    }
  }

  async function deleteMessage(item: Message) {
    if (!window.confirm("Удалить это сообщение?")) return;
    try {
      await apiRequest(`/api/messages/${item.id}`, { method: "DELETE" });
      setMessages((previous) => previous.filter((message) => message.id !== item.id));
      notify("Сообщение удалено.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось удалить сообщение", true);
    }
  }

  function editMessage(item: Message) {
    setEditingMessageId(Number(item.id));
    setEditDraft(item.content ?? "");
  }

  function cancelEditMessage() {
    setEditingMessageId(null);
    setEditDraft("");
  }

  async function saveEditedMessage(item: Message) {
    const messageId = Number(item.id);
    const content = editDraft.trim();

    if (!Number.isInteger(messageId) || messageId < 1) {
      notify("Не удалось определить ID сообщения.", true);
      return;
    }
    if (!content) {
      notify("Сообщение не может быть пустым.", true);
      return;
    }

    try {
      const updated = await apiRequest<Message>(`/api/messages/${messageId}`, {
        method: "PUT",
        body: JSON.stringify({ content }),
      });

      setMessages((previous) =>
        previous.map((message) =>
          Number(message.id) === messageId ? { ...message, ...updated } : message
        )
      );
      setEditingMessageId(null);
      setEditDraft("");
      notify("Сообщение обновлено.");
    } catch (error) {
      notify(
        error instanceof Error ? error.message : "Ошибка сохранения сообщения.",
        true
      );
    }
  }

  async function invitePrivateMember() {
    if (!channel || channel.visibility !== "private") return;

    const target = window.prompt("Имя участника сообщества для приглашения:");
    if (!target || !target.trim()) return;

    try {
      await apiRequest(`/api/channels/${channel.id}/members`, {
        method: "POST",
        body: JSON.stringify({ username: target.trim() }),
      });
      notify(`Участник ${target.trim()} приглашён в закрытый канал.`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось пригласить участника", true);
    }
  }


  const filtered = communities.filter((item) =>
    `${item.name} ${item.description || ""}`.toLowerCase().includes(search.toLowerCase()),
  );


  async function saveProfile(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setProfileSaving(true);
    try {
      const updated = await apiRequest<ProfileData>("/api/profile/me", {
        method: "PATCH",
        body: JSON.stringify({
          display_name: profileDraft.display_name.trim(),
          bio: profileDraft.bio.trim(),
          avatar_url: profileDraft.avatar_url.trim(),
          status: profileDraft.status,
        }),
      });
      const normalized: ProfileData = {
        display_name: updated.display_name || "",
        bio: updated.bio || "",
        avatar_url: updated.avatar_url || "",
        status: updated.status || "online",
      };
      setProfile(normalized);
      setProfileDraft(normalized);
      setShowProfileEditor(false);
      notify("Профиль сохранён.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось сохранить профиль.", true);
    } finally {
      setProfileSaving(false);
    }
  }

  async function loadFriends() {
    setFriendsLoading(true);
    try {
      const result = await apiRequest<FriendsResponse>("/api/friends");
      setFriends(Array.isArray(result.friends) ? result.friends : []);
      setIncomingFriends(Array.isArray(result.incoming) ? result.incoming : []);
      setOutgoingFriends(Array.isArray(result.outgoing) ? result.outgoing : []);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось загрузить друзей.", true);
    } finally {
      setFriendsLoading(false);
    }
  }

  async function sendFriendRequest(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = friendUsername.trim();
    if (!name) return;
    try {
      const result = await apiRequest<{status: string; username?: string}>("/api/friends/requests", {
        method: "POST",
        body: JSON.stringify({ username: name }),
      });
      setFriendUsername("");
      await loadFriends();
      const labels: Record<string, string> = {
        pending: "Запрос дружбы отправлен.",
        accepted: "Вы теперь друзья.",
        already_pending: "Запрос уже отправлен.",
        already_friends: "Этот пользователь уже в друзьях.",
      };
      notify(labels[result.status] || "Запрос обработан.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось отправить запрос.", true);
    }
  }

  async function answerFriendRequest(item: FriendItem, action: "accept" | "reject") {
    if (!item.request_id) return;
    try {
      await apiRequest(`/api/friends/requests/${item.request_id}`, {
        method: "PATCH",
        body: JSON.stringify({ action }),
      });
      await loadFriends();
      notify(action === "accept" ? "Запрос принят." : "Запрос отклонён.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось обработать запрос.", true);
    }
  }

  async function cancelFriendRequest(item: FriendItem) {
    try {
      const token = localStorage.getItem("comind_access_token");
      const response = await fetch(`${API}/api/friends/requests/${item.id}`, {
        method: "DELETE",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });

      if (!response.ok) {
        const detail = await response.text();
        throw new Error(detail || `Ошибка HTTP ${response.status}`);
      }

      setNoticeError(false);
      setNotice("Запрос в друзья отменён.");
      await loadFriends();
    } catch (error) {
      setNoticeError(true);
      setNotice(
        error instanceof Error
          ? error.message
          : "Не удалось отозвать запрос в друзья."
      );
    }
  }

  async function removeFriend(item: FriendItem) {
    if (!window.confirm(`Удалить ${item.username} из друзей?`)) return;
    try {
      await apiRequest(`/api/friends/${item.id}`, { method: "DELETE" });
      await loadFriends();
      notify("Пользователь удалён из друзей.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось удалить друга.", true);
    }
  }

  async function renameChannel(item: Channel) {
    const entered = window.prompt("Новое название канала:", item.name);
    if (entered === null) return;
    const name = entered.trim();
    if (!/^[a-zA-Z0-9_-]{2,50}$/.test(name)) {
      notify("Название: 2–50 символов, латиница, цифры, _ или -.", true);
      return;
    }
    try {
      const updated = await apiRequest<{id: number; name: string}>(
        `/api/channels/${item.id}`,
        { method: "PATCH", body: JSON.stringify({ name }) }
      );
      const nextName = updated.name || name;
      setChannels((previous) => previous.map((entry) =>
        entry.id === item.id ? { ...entry, name: nextName } : entry
      ));
      setChannel((previous) =>
        previous && previous.id === item.id ? { ...previous, name: nextName } : previous
      );
      notify("Канал переименован.");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось переименовать канал.", true);
    }
  }




  async function leaveCommunity(item: Community) {
    if (!window.confirm(`Покинуть сообщество «${item.name}»?`)) return;
    setLoading(true);
    try {
      await apiRequest(`/api/communities/${item.id}/leave`, { method: "DELETE" });
      setCommunity(null);
      setChannel(null);
      setChannels([]);
      setMessages([]);
      await loadCommunities();
      notify(`Ты покинул сообщество «${item.name}».`);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Не удалось покинуть сообщество.", true);
    } finally {
      setLoading(false);
    }
  }


  return (
    <main className="comind">
      <aside className="comind-rail">
        <div className="comind-logo">C<span>.</span></div>
        <button className="rail-home active" title="Сообщества" onClick={() => {
          setCommunity(null);
          setChannel(null);
        }}>⌂</button>
        <div className="rail-divider" />
        {communities.slice(0, 8).map((item) => (
          <button
            key={item.id}
            className={`rail-community ${community?.id === item.id ? "selected" : ""}`}
            title={item.name}
            onClick={() => void chooseCommunity(item)}
          >
            {(item.name || "?").slice(0, 2).toUpperCase()}
          </button>
        ))}
        <button className="rail-add" title="Создать сообщество" onClick={() => setShowCreateCommunity(true)}>＋</button>
        <div className="rail-spacer" />
        <button className="rail-profile" title={username}>{(profile.display_name || username || "U").slice(0, 1).toUpperCase()}</button>
      </aside>

      <aside className="comind-sidebar">
        <header className="sidebar-header">
          <div>
            <div className="eyebrow">GAMING COMMUNITY</div>
            <h1>COMIND<span> SOON</span></h1>
          </div>
          <button className="icon-button" title="Обновить" onClick={() => void loadCommunities()}>↻</button>
        </header>

        <div className="user-card">
          <div className="user-avatar">{(profile.display_name || username || "U").slice(0, 1).toUpperCase()}</div>
          <div className="user-info">
            <strong>{profile.display_name.trim() || username}</strong>
            <span className={"profile-status profile-status-" + profile.status}>
              <i className={"online-dot profile-dot-" + profile.status} />
              {({ online: "В сети", away: "Не активен", busy: "Не беспокоить", offline: "Не в сети" } as Record<string, string>)[profile.status] || "В сети"}
            </span>
            {userIsAdmin && <span className="admin-role-badge">ADMIN</span>}
          </div>
          <button className="icon-button" title="Редактировать профиль" onClick={() => { setProfileDraft(profile); setShowProfileEditor(true); }}>⚙</button>
          <button className="icon-button" title="Выйти" onClick={onLogout}>⇥</button>
        </div>

        <button type="button" className="friends-open-button" onClick={() => { setShowFriendsPanel(true); void loadFriends(); }}>
          ♧ Друзья
        </button>

        <div className="sidebar-section-title">
          <span>СООБЩЕСТВА</span>
          <button className="tiny-add" title="Создать сообщество" onClick={() => setShowCreateCommunity(true)}>＋</button>
        </div>

        <label className="search-box">
          <span>⌕</span>
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Найти сообщество..." />
        </label>

        <div className="community-list">
          {filtered.map((item) => (
            <div key={item.id} className={`community-entry ${community?.id === item.id ? "current" : ""}`}>
              <button className="community-select" onClick={() => void chooseCommunity(item)}>
                <span className="community-avatar">{item.name.slice(0, 1).toUpperCase()}</span>
                <span className="community-copy">
                  <strong>{item.name}</strong>
                  <small>{item.member_count ?? 0} участников</small>
                </span>
              </button>
              <button className="join-button" title="Вступить" onClick={() => void joinCommunity(item)} disabled={loading} aria-label={`Вступить в ${item.name}`}>{loading ? "…" : "↗"}</button>
            </div>
          ))}
          {!filtered.length && <p className="empty-small">Сообществ пока нет. Создай первое.</p>}
        </div>

        <div className="sidebar-footer">
          <span className="status-led" /> API CLIENT
          <span className="version">EARLY ACCESS</span>
        </div>
      </aside>

      <section className="comind-workspace">
        {notice && (
          <div className={`notice ${noticeError ? "notice-error" : ""}`}>
            <span>{notice}</span>
            <button onClick={() => setNotice("")}>×</button>
          </div>
        )}

        {community ? (
          <>
            <header className="workspace-header">
              <div className="workspace-community-icon">{community.name.slice(0, 1).toUpperCase()}</div>
              <div className="workspace-title">
                <h2>{community.name}</h2>
                <p>{community.description || "Игровое сообщество COMIND"}</p>
              </div>
              <div className="header-actions">
                <span className="connection-pill"><i /> LIVE API</span>
                <button
                  className="secondary-button"
                  disabled={loading || (userId !== undefined && Number(community.owner_id) === userId)}
                  title={userId !== undefined && Number(community.owner_id) === userId ? "Владелец не может покинуть своё сообщество" : "Покинуть сообщество"}
                  onClick={() => void leaveCommunity(community)}
                >
                  {userId !== undefined && Number(community.owner_id) === userId ? "Владелец сообщества" : "Выйти из сообщества"}
                </button>
              </div>
            </header>

            <div className="workspace-body">
              <aside className="channel-sidebar">
                <div className="channel-heading">
                  <span>КАНАЛЫ</span>
                  <button className="tiny-add" title="Создать канал" onClick={() => setShowCreateChannel(true)}>＋</button>
                </div>
                {channels.map((item) => (
                  <div className="channel-row" key={item.id}>
                    <button
                      className={`channel-item ${channel?.id === item.id ? "active" : ""}`}
                      onClick={() => setChannel(item)}
                    >
                      <span className="channel-symbol">{item.visibility === "private" ? "🔒" : item.channel_type === "voice" ? "◖" : "#"}</span>
                      <span>{item.name}</span>
                    </button>
                    <button
                      type="button"
                      className="channel-rename"
                      title={"Переименовать канал " + item.name}
                      aria-label={"Переименовать канал " + item.name}
                      onClick={() => void renameChannel(item)}
                    >✎</button>
                  </div>
                ))}
                {!channels.length && <p className="empty-small">Нет доступных каналов.</p>}
                <div className="channel-bottom">
                  <div className="channel-heading">ГОЛОС И ВИДЕО</div>
                  <div className="feature-placeholder"><span>◖</span><div><b>Голосовые комнаты</b><small>Следующий этап</small></div></div>
                  <div className="feature-placeholder"><span>▣</span><div><b>Демонстрация экрана</b><small>Следующий этап</small></div></div>
                </div>
              </aside>

              <section className="chat-panel">
                {channel && channel.channel_type === "voice" ? (
                  <VoiceRoom key={channel.id} channelId={channel.id} channelName={channel.name} username={username} />
                ) : (
                  <>
                <header className="chat-header">
                  <div className="chat-hash">#</div>
                  <div><h3>{channel?.name || "Выбери канал"}</h3><p>{channel?.visibility === "private" ? "Закрытый канал · доступ по приглашению" : "Открытый канал сообщества"}</p></div>
                  <div className="chat-header-right">{channel?.visibility === "private" && <button type="button" className="private-invite" onClick={() => void invitePrivateMember()}>＋ Пригласить</button>}<span>{messages.length} сообщений</span><button className="icon-button" title="Обновить каналы" onClick={() => void loadChannels(community)}>↻</button></div>
                </header>

                <div className="message-list">
                  {!channel && <div className="empty-state"><div className="empty-symbol">#</div><h3>Выбери канал</h3><p>Выбери канал слева, чтобы открыть переписку.</p></div>}
                  {channel && messages.length === 0 && <div className="empty-state"><div className="empty-symbol">✳</div><h3>Начни общение</h3><p>Здесь пока нет сообщений. Напиши первым.</p></div>}
                  {messages.map((item, index) => {
                    const author = String(item.username || item.author_name || item.author || (item.user_id === undefined ? "Участник" : `Участник ${item.user_id}`));
                    return (
                      <article className="message" key={item.id ?? `${index}-${item.content}`}>
                        <div className="message-avatar">{author.slice(0, 1).toUpperCase()}</div>
                        <div className="message-body">
                          <div className="message-meta">
                            <strong>{author}</strong>
                            {item.status && (
                              <span className={"message-presence presence-" + item.status}>
                                {({ online: "В сети", away: "Не активен", busy: "Не беспокоить", offline: "Не в сети" } as Record<string, string>)[item.status] || item.status}
                              </span>
                            )}
                            <time>{item.created_at ? new Date(item.created_at).toLocaleString("ru-RU") : ""}</time>
                          </div>
                          {editingMessageId === Number(item.id) ? (
                            <div className="inline-message-editor">
                              <textarea
                                autoFocus
                                rows={3}
                                maxLength={4000}
                                value={editDraft}
                                onChange={(event) => setEditDraft(event.target.value)}
                                onKeyDown={(event) => {
                                  if (event.key === "Escape") cancelEditMessage();
                                  if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
                                    event.preventDefault();
                                    void saveEditedMessage(item);
                                  }
                                }}
                              />
                              <div className="inline-message-editor-actions">
                                <button type="button" onClick={() => void saveEditedMessage(item)}>
                                  Сохранить
                                </button>
                                <button type="button" onClick={cancelEditMessage}>
                                  Отмена
                                </button>
                              </div>
                              <small>Ctrl+Enter — сохранить · Esc — отменить</small>
                            </div>
                          ) : (
                            <p>{item.content}</p>
                          )}
                        </div>
                        {(item.username === username || userIsAdmin) && (
                          <button className="message-edit" title="Редактировать сообщение" onClick={() => void editMessage(item)}>✎</button>
                        )}
                        <button className="message-delete" title="Удалить сообщение" onClick={() => void deleteMessage(item)}>×</button>
                      </article>
                    );
                  })}
                </div>

                <form className="message-composer" onSubmit={sendMessage}>
                  <button type="button" className="composer-plus" title="Дополнительные функции" onClick={() => notify("Вложения будут добавлены следующим этапом.")}>＋</button>
                  <input
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder={channel ? `Написать в #${channel.name}` : "Сначала выбери канал"}
                    disabled={!channel || loading}
                    maxLength={4000}
                  />
                  <span className="composer-hint">Enter ↵</span>
                  <button className="send-button" type="submit" disabled={!channel || !messageText.trim() || loading}>➤</button>
                </form>
                <div className="chat-footnote">Пожалуйста, соблюдай правила сообщества.</div>
                  </>
                )}
              </section>

              <aside className="members-panel">
                <div className="members-heading">СООБЩЕСТВО</div>
                <div className="community-cover"><div className="cover-orb orb-one" /><div className="cover-orb orb-two" /><span>{community.name.slice(0, 1).toUpperCase()}</span></div>
                <h3 className="member-community-name">{community.name}</h3>
                <p className="member-description">{community.description || "Место для общения, игр и совместных проектов."}</p>
                <div className="member-stat-row"><span>Участники</span><strong>{community.member_count ?? "—"}</strong></div>
                <div className="member-stat-row"><span>Каналы</span><strong>{channels.length}</strong></div>
                <div className="member-stat-row"><span>Соединение</span><strong className="green-text">API</strong></div>
                <button className="wide-primary" onClick={() => void joinCommunity(community)} disabled={loading}>Вступить в сообщество</button>
                <div className="next-features"><span>В РАЗРАБОТКЕ</span><p>Роли и права доступа</p><p>Голосовые комнаты</p><p>AI-помощник</p><p>Рейтинг и достижения</p></div>
              </aside>
            </div>
          </>
        ) : (
          <div className="discover-view">
            <header className="discover-top"><span className="connection-pill"><i /> COMIND PLATFORM</span><button className="secondary-button" onClick={() => void loadCommunities()}>↻ Обновить</button></header>
            <div className="discover-content">
              <div className="hero-label"><span /> ТВОЯ ИГРОВАЯ СРЕДА</div>
              <h2>Играй вместе.<br /><span>Создавай сообщества.</span></h2>
              <p className="hero-description">Единое пространство для игровых сообществ, общения и совместных проектов.</p>
              <div className="discover-actions"><button className="primary-button" onClick={() => setShowCreateCommunity(true)}>＋ Создать сообщество</button><button className="secondary-button" onClick={() => document.getElementById("community-catalog")?.scrollIntoView({ behavior: "smooth" })}>Найти сообщество ↓</button></div>
              <div className="feature-grid">
                <div className="feature-card"><span className="feature-icon purple">⌘</span><h3>Свои сообщества</h3><p>Создавай пространства и собирай игроков.</p></div>
                <div className="feature-card"><span className="feature-icon blue">#</span><h3>Общение</h3><p>Текстовые каналы и сообщения, подключённые к backend.</p></div>
                <div className="feature-card"><span className="feature-icon pink">✧</span><h3>Развитие</h3><p>Роли, достижения, голос и AI — следующие модули.</p></div>
              </div>
              <div id="community-catalog" className="catalog-heading"><div><span className="eyebrow">ОТКРЫТЬ НОВОЕ</span><h3>Сообщества</h3></div><span>{filtered.length} найдено</span></div>
              <div className="discover-community-grid">
                {filtered.map((item) => <button key={item.id} className="discover-community-card" onClick={() => void chooseCommunity(item)}><div className="discover-card-icon">{item.name.slice(0, 1).toUpperCase()}</div><div><strong>{item.name}</strong><p>{item.description || "Игровое сообщество COMIND"}</p><small>{item.member_count ?? 0} участников</small></div><span className="card-arrow">↗</span></button>)}
                {!filtered.length && <div className="catalog-empty">Сообщества не найдены. Создай своё или обнови список.</div>}
              </div>
            </div>
          </div>
        )}
      </section>

      {/* PROFILE_AND_FRIENDS_MODALS_V1 */}
      {showProfileEditor && (
        <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowProfileEditor(false); }}>
          <form className="comind-modal account-profile-modal" onSubmit={saveProfile}>
            <button type="button" className="modal-close" onClick={() => setShowProfileEditor(false)}>×</button>
            <span className="eyebrow">АККАУНТ</span>
            <h2>Профиль</h2>
            <label>Отображаемое имя
              <input value={profileDraft.display_name} maxLength={60}
                onChange={(e) => setProfileDraft((p) => ({ ...p, display_name: e.target.value }))}
                placeholder={username} />
            </label>
            <label>О себе
              <textarea value={profileDraft.bio} rows={3} maxLength={500}
                onChange={(e) => setProfileDraft((p) => ({ ...p, bio: e.target.value }))}
                placeholder="Расскажи о себе" />
            </label>
            <label>Статус
              <select value={profileDraft.status}
                onChange={(e) => setProfileDraft((p) => ({ ...p, status: e.target.value as ProfileData["status"] }))}>
                <option value="online">В сети</option>
                <option value="away">Не активен</option>
                <option value="busy">Не беспокоить</option>
                <option value="offline">Не в сети</option>
              </select>
            </label>
            <label>URL аватара (HTTPS)
              <input value={profileDraft.avatar_url} maxLength={500000}
                onChange={(e) => setProfileDraft((p) => ({ ...p, avatar_url: e.target.value }))}
                placeholder="https://..." />
            </label>
            <button className="wide-primary" type="submit" disabled={profileSaving}>
              {profileSaving ? "Сохраняем..." : "Сохранить профиль"}
            </button>
          </form>
        </div>
      )}

      {showFriendsPanel && (
        <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowFriendsPanel(false); }}>
          <section className="comind-modal friends-modal">
            <button type="button" className="modal-close" onClick={() => setShowFriendsPanel(false)}>×</button>
            <span className="eyebrow">СОЦИАЛЬНАЯ СЕТЬ</span>
            <h2>Друзья</h2>
            <form className="friend-add-form" onSubmit={sendFriendRequest}>
              <label>Имя пользователя
                <input value={friendUsername} required minLength={3} maxLength={32}
                  pattern="[A-Za-z0-9_]+"
                  onChange={(e) => setFriendUsername(e.target.value)}
                  placeholder="Например, player_01" />
              </label>
              <button className="wide-primary" type="submit">Отправить запрос</button>
            </form>

            <div className="friends-modal-section">
              <h3>Входящие запросы · {incomingFriends.length}</h3>
              {incomingFriends.map((item) => (
                <div className="friend-entry" key={item.request_id}>
                  <strong>{item.display_name || item.username}</strong>
                  <div>
                    <button type="button" onClick={() => void answerFriendRequest(item, "accept")}>Принять</button>
                    <button type="button" onClick={() => void answerFriendRequest(item, "reject")}>Отклонить</button>
                  </div>
                </div>
              ))}
              {!incomingFriends.length && <p className="empty-small">Нет входящих запросов.</p>}
            </div>

            <div className="friends-modal-section">
              <h3>Мои друзья · {friends.length}</h3>
              {friends.map((item) => (
                <div className="friend-entry" key={item.id}>
                  <strong>{item.display_name || item.username}</strong>
                  <button type="button" onClick={() => void removeFriend(item)}>Удалить</button>
                </div>
              ))}
              {!friends.length && <p className="empty-small">Пока нет друзей.</p>}
            </div>

            <div className="friends-modal-section">
              <h3>Отправленные запросы · {outgoingFriends.length}</h3>
              {outgoingFriends.map((item) => (
                <div className="friend-entry" key={item.request_id}>
                  <span>{item.display_name || item.username}</span>
                  <small>Ожидает ответа</small>
                </div>
              ))}
            </div>

            <button type="button" className="secondary-button" disabled={friendsLoading} onClick={() => void loadFriends()}>
              {friendsLoading ? "Обновляем..." : "Обновить список"}
            </button>
          </section>
        </div>
      )}

      {showFriendsPanel && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowFriendsPanel(false); }}>
          <section className="comind-modal friends-modal">
            <button type="button" className="modal-close" onClick={() => setShowFriendsPanel(false)}>×</button>
            <span className="eyebrow">СОЦИАЛЬНАЯ СЕТЬ</span>
            <h2>Друзья</h2>
            <form className="friend-add-form" onSubmit={sendFriendRequest}>
              <label>Имя пользователя
                <input value={friendUsername} onChange={(event) => setFriendUsername(event.target.value)}
                  minLength={3} maxLength={32} pattern="[A-Za-z0-9_]+"
                  placeholder="Например, player_01" required />
              </label>
              <button type="submit" className="wide-primary">Отправить запрос</button>
            </form>

            <div className="friends-modal-section">
              <h3>Входящие · {incomingFriends.length}</h3>
              {incomingFriends.map((item) => (
                <div className="friend-entry" key={item.request_id}>
                  <strong>{item.display_name || item.username}</strong>
                  <div>
                    <button type="button" onClick={() => void answerFriendRequest(item, "accept")}>Принять</button>
                    <button type="button" onClick={() => void answerFriendRequest(item, "reject")}>Отклонить</button>
                  </div>
                </div>
              ))}
              {!incomingFriends.length && <p className="empty-small">Нет входящих запросов.</p>}
            </div>

            <div className="friends-modal-section">
              <h3>Друзья · {friends.length}</h3>
              {friends.map((item) => (
                <div className="friend-entry" key={item.id}>
                  <div>
                    <strong>{item.display_name || item.username}</strong>
                    <small>{item.status || "offline"}</small>
                  </div>
                  <button type="button" onClick={() => void removeFriend(item)}>Удалить</button>
                </div>
              ))}
              {!friends.length && <p className="empty-small">Пока нет друзей.</p>}
            </div>

            <div className="friends-modal-section">
              <h3>Отправленные · {outgoingFriends.length}</h3>
              {outgoingFriends.map((item) => (
                <div className="friend-entry" key={item.request_id}>
                  <strong>{item.display_name || item.username}</strong>
                  <button type="button" onClick={() => void cancelFriendRequest(item)}>Отозвать</button>
                </div>
              ))}
              {!outgoingFriends.length && <p className="empty-small">Нет ожидающих запросов.</p>}
            </div>

            <button type="button" className="secondary-button" disabled={friendsLoading}
              onClick={() => void loadFriends()}>
              {friendsLoading ? "Обновляем..." : "Обновить список"}
            </button>
          </section>
        </div>
      )}

      {showCreateCommunity && (
        <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowCreateCommunity(false); }}>
          <form className="comind-modal" onSubmit={createCommunity}>
            <button type="button" className="modal-close" onClick={() => setShowCreateCommunity(false)}>×</button>
            <span className="eyebrow">НОВОЕ ПРОСТРАНСТВО</span>
            <h2>Создать сообщество</h2>
            <p>Создай место для своей команды и сообщества.</p>
            <label>Название<input autoFocus value={communityName} onChange={(e) => setCommunityName(e.target.value)} maxLength={80} required placeholder="Например, Minecraft Squad" /></label>
            <label>Описание<textarea value={communityDescription} onChange={(e) => setCommunityDescription(e.target.value)} maxLength={500} placeholder="О чём ваше сообщество?" rows={3} /></label>
            <button className="wide-primary" type="submit" disabled={loading}>{loading ? "Создаём..." : "Создать сообщество"}</button>
          </form>
        </div>
      )}

      {showCreateChannel && (
        <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setShowCreateChannel(false); }}>
          <form className="comind-modal" onSubmit={createChannel}>
            <button type="button" className="modal-close" onClick={() => setShowCreateChannel(false)}>×</button>
            <span className="eyebrow">НАСТРОЙКА СООБЩЕСТВА</span>
            <h2>Новый канал</h2>
            <p>Канал будет создан в «{community?.name}». По текущим правилам backend это может сделать владелец сообщества.</p>
            <label>Название канала<input autoFocus value={channelName} onChange={(e) => setChannelName(e.target.value)} maxLength={50} required placeholder="например, обсуждение" /></label>
            <label>Доступ
              <select value={channelVisibility} onChange={(e) => setChannelVisibility(e.target.value as "public" | "private")}>
                <option value="public">Открытый — участники сообщества</option>
                <option value="private">Закрытый — только приглашённые</option>
              </select>
            </label>
            <button className="wide-primary" type="submit" disabled={loading}>{loading ? "Создаём..." : "Создать канал"}</button>
          </form>
        </div>
      )}
          <button
        className="feature-launcher"
        onClick={() => setShowFeaturePanel(true)}
      >
        Все функции
      </button>

      {showFeaturePanel && (
        <FeaturePanel
          username={username}
          communityId={community?.id ?? null}
          channelId={channel?.id ?? null}
          onClose={() => setShowFeaturePanel(false)}
          onRefresh={() => {
            void loadProfile();
            void loadCommunities();
            if (community) void loadChannels(community);
          }}
          onCommunityDeleted={() => {
            setCommunity(null);
            setChannel(null);
            void loadCommunities();
          }}
        />
      )}
</main>
  );
}


