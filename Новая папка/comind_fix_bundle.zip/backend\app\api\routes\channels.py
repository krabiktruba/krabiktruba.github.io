from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.api.routes.auth import current_user
from app.repositories import channel_repository as repo
from app.schemas.channel import ChannelCreate, MessageCreate
from app.services import channel_service

router = APIRouter(tags=["Channels and Messages"])


def is_admin(user: dict) -> bool:
    return bool(user.get("is_admin", 0))


def require_channel_access(channel_id: int, user: dict) -> dict:
    channel = channel_service.get_channel(channel_id)
    if channel is None:
        raise HTTPException(status_code=404, detail="Канал не найден")
    if not repo.can_access_channel(channel_id, user["id"], is_admin(user)):
        raise HTTPException(status_code=403, detail="Нет доступа к этому каналу")
    return channel


@router.get("/api/communities/{community_id}/channels")
def get_channels(community_id: int, user: dict = Depends(current_user)):
    if not repo.community_exists(community_id):
        raise HTTPException(status_code=404, detail="Сообщество не найдено")

    if (
        not repo.is_member(community_id, user["id"])
        and not is_admin(user)
    ):
        raise HTTPException(
            status_code=403,
            detail="Вступите в сообщество, чтобы просматривать каналы",
        )

    channels = channel_service.get_channels(community_id)
    return [
        channel for channel in channels
        if repo.can_access_channel(channel["id"], user["id"], is_admin(user))
    ]


@router.post("/api/communities/{community_id}/channels", status_code=201)
def create_channel(
    community_id: int,
    data: ChannelCreate,
    user: dict = Depends(current_user),
):
    if not repo.community_exists(community_id):
        raise HTTPException(status_code=404, detail="Сообщество не найдено")

    if not repo.is_owner(community_id, user["id"]) and not is_admin(user):
        raise HTTPException(
            status_code=403,
            detail="Создавать каналы может только владелец сообщества или администратор",
        )

    try:
        return channel_service.create_text_channel(
            community_id,
            data.name,
            user["id"],
            data.visibility,
        )
    except ValueError as error:
        raise HTTPException(status_code=409, detail=str(error))


@router.get("/api/channels/{channel_id}/messages")
def get_messages(
    channel_id: int,
    limit: int = Query(default=50, ge=1, le=100),
    user: dict = Depends(current_user),
):
    channel = require_channel_access(channel_id, user)

    if channel["channel_type"] != "text":
        raise HTTPException(
            status_code=400,
            detail="История сообщений доступна только для текстовых каналов",
        )

    return channel_service.get_messages(channel_id, limit)


@router.post("/api/channels/{channel_id}/messages", status_code=201)
def send_message(
    channel_id: int,
    data: MessageCreate,
    user: dict = Depends(current_user),
):
    channel = require_channel_access(channel_id, user)

    if channel["channel_type"] != "text":
        raise HTTPException(
            status_code=400,
            detail="Отправлять сообщения можно только в текстовые каналы",
        )

    content = data.content.strip()
    if not content:
        raise HTTPException(status_code=422, detail="Сообщение не может быть пустым")

    return channel_service.send_message(channel_id, user["id"], content)


@router.put("/api/messages/{message_id}")
def edit_message(
    message_id: int,
    data: MessageCreate,
    user: dict = Depends(current_user),
):
    message = repo.get_message(message_id)
    if message is None:
        raise HTTPException(status_code=404, detail="Сообщение не найдено")

    is_author = int(message["user_id"]) == int(user["id"])
    is_owner = repo.is_owner(message["community_id"], user["id"])
    is_admin = bool(user.get("is_admin", 0))

    if not is_author and not is_owner and not is_admin:
        raise HTTPException(
            status_code=403,
            detail="Редактировать сообщение может его автор, владелец сообщества или администратор",
        )

    content = data.content.strip()
    if not content:
        raise HTTPException(status_code=422, detail="Сообщение не может быть пустым")

    updated = repo.update_message(message_id, content)
    if updated is None:
        raise HTTPException(status_code=404, detail="Сообщение не найдено")
    return updated


@router.delete("/api/messages/{message_id}")
def delete_message(
    message_id: int,
    user: dict = Depends(current_user),
):
    message = repo.get_message(message_id)
    if message is None:
        raise HTTPException(status_code=404, detail="Сообщение не найдено")

    is_author = message["user_id"] == user["id"]
    is_owner = repo.is_owner(message["community_id"], user["id"])

    if not is_author and not is_owner and not is_admin(user):
        raise HTTPException(
            status_code=403,
            detail="Недостаточно прав для удаления сообщения",
        )

    repo.delete_message(message_id)
    return {"status": "deleted", "message_id": message_id}


class ChannelInvite(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[a-zA-Z0-9_]+$")


@router.post("/api/channels/{channel_id}/members", status_code=201)
def invite_channel_member(
    channel_id: int,
    data: ChannelInvite,
    user: dict = Depends(current_user),
):
    channel = require_channel_access(channel_id, user)

    if channel.get("visibility", "public") != "private":
        raise HTTPException(
            status_code=400,
            detail="Приглашения нужны только для закрытого канала",
        )

    target = repo.find_community_member(channel["community_id"], data.username)
    if target is None:
        raise HTTPException(
            status_code=404,
            detail="Пользователь не найден среди участников этого сообщества",
        )

    repo.add_channel_member(channel_id, target["id"])
    return {
        "status": "invited",
        "username": target["username"],
        "channel_id": channel_id,
    }
