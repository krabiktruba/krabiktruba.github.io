from fastapi import APIRouter, Depends, HTTPException

from app.api.routes.auth import current_user
from app.core.database import get_db
from app.schemas.community import CommunityCreate
from app.services import community_service

router = APIRouter(prefix="/api/communities", tags=["Communities"])


@router.post("/", status_code=201)
def create_community(
    data: CommunityCreate,
    user: dict = Depends(current_user),
):
    return community_service.create(
        data.name,
        data.description,
        user["id"],
    )


@router.get("/")
def get_communities():
    return community_service.get_all()


@router.get("/{community_id}")
def get_community(community_id: int):
    community = community_service.get_one(community_id)
    if community is None:
        raise HTTPException(status_code=404, detail="Сообщество не найдено")
    return community


@router.post("/{community_id}/join")
def join_community(
    community_id: int,
    user: dict = Depends(current_user),
):
    joined = community_service.join(community_id, user["id"])
    if not joined:
        raise HTTPException(status_code=404, detail="Сообщество не найдено")
    return {"status": "joined", "community_id": community_id}


@router.get("/{community_id}/members")
def get_members(community_id: int):
    if community_service.get_one(community_id) is None:
        raise HTTPException(status_code=404, detail="Сообщество не найдено")
    return community_service.get_members(community_id)


@router.delete("/{community_id}/leave")
def leave_community(community_id: int, user: dict = Depends(current_user)):
    with get_db() as db:
        community = db.execute(
            "SELECT id, owner_id FROM communities WHERE id=?",
            (community_id,),
        ).fetchone()

        if community is None:
            raise HTTPException(404, "Сообщество не найдено")
        if community["owner_id"] == user["id"]:
            raise HTTPException(
                409,
                "Владелец не может выйти из сообщества. Передайте владение или удалите сообщество.",
            )

        membership = db.execute(
            "SELECT role FROM community_members WHERE community_id=? AND user_id=?",
            (community_id, user["id"]),
        ).fetchone()

        if membership is None:
            raise HTTPException(404, "Вы не состоите в этом сообществе")

        db.execute("""
            DELETE FROM channel_members
            WHERE user_id=? AND channel_id IN (
                SELECT id FROM channels WHERE community_id=?
            )
        """, (user["id"], community_id))

        db.execute("""
            DELETE FROM voice_signals
            WHERE channel_id IN (SELECT id FROM channels WHERE community_id=?)
              AND (sender_id=? OR receiver_id=?)
        """, (community_id, user["id"], user["id"]))

        db.execute(
            "DELETE FROM voice_presence WHERE community_id=? AND user_id=?",
            (community_id, user["id"]),
        )
        db.execute(
            "DELETE FROM community_members WHERE community_id=? AND user_id=?",
            (community_id, user["id"]),
        )

        return {"status": "left", "community_id": community_id}
