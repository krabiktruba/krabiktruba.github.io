import sqlite3
from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from app.core.database import get_db, DATABASE_PATH
from app.api.routes.auth import current_user

router = APIRouter(tags=["COMIND SOON Extended Features"])

def init_extended():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS notifications (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '',
          is_read INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS reports (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          reporter_id INTEGER NOT NULL REFERENCES users(id),
          target_user_id INTEGER REFERENCES users(id),
          message_id INTEGER,
          reason TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'open',
          moderator_id INTEGER REFERENCES users(id),
          resolution TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS moderation_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          actor_id INTEGER NOT NULL REFERENCES users(id),
          community_id INTEGER REFERENCES communities(id) ON DELETE CASCADE,
          target_user_id INTEGER REFERENCES users(id),
          action TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS user_blocks (
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          blocked_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          reason TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY(user_id, blocked_user_id)
        );
        CREATE TABLE IF NOT EXISTS voice_presence (
          community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
          channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          muted INTEGER NOT NULL DEFAULT 0,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY(channel_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS voice_signals (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
          channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
          sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          receiver_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          payload TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id,is_read);
        CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
        CREATE INDEX IF NOT EXISTS idx_messages_channel ON messages(channel_id,id);
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS friend_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                receiver_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK(status IN ('pending', 'accepted', 'rejected')),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CHECK(sender_id <> receiver_id),
                UNIQUE(sender_id, receiver_id)
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver
            ON friend_requests(receiver_id, status)
        """)

        community_columns = {
            r["name"] for r in db.execute("PRAGMA table_info(communities)")
        }

        if "visibility" not in community_columns:
            db.execute(
                "ALTER TABLE communities ADD COLUMN visibility TEXT NOT NULL DEFAULT 'public'"
            )

        db.execute("""
            CREATE TABLE IF NOT EXISTS community_invitations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                community_id INTEGER NOT NULL
                    REFERENCES communities(id) ON DELETE CASCADE,
                inviter_id INTEGER NOT NULL
                    REFERENCES users(id) ON DELETE CASCADE,
                invitee_id INTEGER NOT NULL
                    REFERENCES users(id) ON DELETE CASCADE,
                status TEXT NOT NULL DEFAULT 'pending'
                    CHECK(status IN ('pending', 'accepted', 'rejected')),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                responded_at TEXT,
                CHECK(inviter_id <> invitee_id)
            )
        """)

        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_community_invites_incoming
            ON community_invitations(invitee_id, status)
        """)

        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_community_invites_pending
            ON community_invitations(community_id, invitee_id)
            WHERE status='pending'
        """)

        columns = {r["name"] for r in db.execute("PRAGMA table_info(users)") }
        for name, declaration in [
            ("display_name", "TEXT NOT NULL DEFAULT ''"),
            ("avatar_url", "TEXT NOT NULL DEFAULT ''"),
            ("bio", "TEXT NOT NULL DEFAULT ''"),
            ("status", "TEXT NOT NULL DEFAULT 'online'"),
            ("is_admin", "INTEGER NOT NULL DEFAULT 0"),
        ]:
            if name not in columns:
                db.execute(f"ALTER TABLE users ADD COLUMN {name} {declaration}")
        columns = {r["name"] for r in db.execute("PRAGMA table_info(messages)")}
        if "edited_at" not in columns:
            db.execute("ALTER TABLE messages ADD COLUMN edited_at TEXT")

class ProfileUpdate(BaseModel):
    display_name: str = Field(default="", max_length=60)
    bio: str = Field(default="", max_length=500)
    avatar_url: str = Field(default="", max_length=500000)
    status: str = Field(default="online", pattern="^(online|away|busy|offline)$")

class CommunityUpdate(BaseModel):
    name: str = Field(min_length=3, max_length=60)
    description: str = Field(default="", max_length=1000)

class ChannelUpdate(BaseModel):
    name: str = Field(min_length=2, max_length=50, pattern=r"^[\w -]+$")

class RoleUpdate(BaseModel):
    role: str = Field(pattern="^(admin|moderator|member)$")

class MessageUpdate(BaseModel):
    content: str = Field(min_length=1, max_length=4000)

class ReportCreate(BaseModel):
    target_user_id: int | None = None
    message_id: int | None = None
    reason: str = Field(min_length=5, max_length=1000)

class ReportResolve(BaseModel):
    status: str = Field(pattern="^(resolved|rejected)$")
    resolution: str = Field(min_length=2, max_length=1000)

class BlockCreate(BaseModel):
    reason: str = Field(default="", max_length=500)

class VoiceSignal(BaseModel):
    receiver_id: int
    payload: str = Field(min_length=1, max_length=50000)

def member(db, cid, uid):
    return db.execute(
        "SELECT role FROM community_members WHERE community_id=? AND user_id=?",
        (cid, uid)
    ).fetchone()

def require_member(db, cid, uid):
    m = member(db, cid, uid)
    if not m:
        raise HTTPException(403, "Вы не участник сообщества")
    return m["role"]

def require_manager(db, cid, uid):
    role = require_member(db, cid, uid)
    if role not in ("owner", "admin", "moderator"):
        raise HTTPException(403, "Недостаточно прав")
    return role

def notify(db, uid, title, body=""):
    db.execute(
        "INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)",
        (uid, title[:200], body[:1000])
    )

def log_action(db, actor, cid, target, action, details=""):
    db.execute(
        "INSERT INTO moderation_log(actor_id,community_id,target_user_id,action,details) VALUES(?,?,?,?,?)",
        (actor, cid, target, action, details[:1000])
    )

@router.get("/api/profile/me")
def get_profile(user=Depends(current_user)):
    with get_db() as db:
        return dict(db.execute(
            "SELECT id,username,email,display_name,avatar_url,bio,status,created_at FROM users WHERE id=?",
            (user["id"],)
        ).fetchone())

@router.patch("/api/profile/me")
def update_profile(data: ProfileUpdate, user=Depends(current_user)):
    avatar = data.avatar_url.strip()
    if avatar and not (avatar.startswith("https://") or avatar.startswith("data:image/png;base64,") or avatar.startswith("data:image/jpeg;base64,") or avatar.startswith("data:image/webp;base64,")):
        raise HTTPException(422, "Аватар должен быть HTTPS URL или PNG/JPEG/WebP data URL")
    if avatar.startswith("data:image/") and len(avatar) > 400000:
        raise HTTPException(413, "Аватар слишком большой")
    with get_db() as db:
        db.execute(
            "UPDATE users SET display_name=?,bio=?,avatar_url=?,status=? WHERE id=?",
            (data.display_name.strip(),data.bio.strip(),avatar,data.status,user["id"])
        )
        return dict(db.execute(
            "SELECT id,username,email,display_name,avatar_url,bio,status,created_at FROM users WHERE id=?",
            (user["id"],)
        ).fetchone())

@router.get("/api/communities/{cid}/members")
def members(cid: int, user=Depends(current_user)):
    with get_db() as db:
        require_member(db,cid,user["id"])
        return [dict(r) for r in db.execute("""
          SELECT u.id AS user_id,u.username,u.display_name,u.avatar_url,u.status,
                 m.role,m.joined_at
          FROM community_members m JOIN users u ON u.id=m.user_id
          WHERE m.community_id=? ORDER BY m.joined_at
        """,(cid,))]

@router.patch("/api/communities/{cid}/members/{target}")
def change_role(cid: int, target: int, data: RoleUpdate, user=Depends(current_user)):
    with get_db() as db:
        actor = require_manager(db,cid,user["id"])
        row = member(db,cid,target)
        if not row:
            raise HTTPException(404,"Участник не найден")
        if actor != "owner":
            raise HTTPException(403,"Назначать роли может только владелец")
        if row["role"] == "owner" or target == user["id"]:
            raise HTTPException(403,"Нельзя изменить роль владельца или собственную роль")
        db.execute("UPDATE community_members SET role=? WHERE community_id=? AND user_id=?",(data.role,cid,target))
        notify(db,target,"Роль в сообществе изменена",data.role)
        log_action(db,user["id"],cid,target,"role_changed",data.role)
        return {"status":"updated","user_id":target,"role":data.role}

@router.patch("/api/communities/{cid}")
def update_community(cid: int, data: CommunityUpdate, user=Depends(current_user)):
    with get_db() as db:
        community = db.execute(
            "SELECT id, owner_id FROM communities WHERE id=?",
            (cid,),
        ).fetchone()

        if community is None:
            raise HTTPException(404, "\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d")

        membership = member(db, cid, user["id"])
        role = str(membership["role"]).lower() if membership else ""

        owner_id = community["owner_id"]
        is_owner = (
            owner_id is not None and int(owner_id) == int(user["id"])
        ) or role == "owner"

        is_admin = role in ("admin", "administrator")
        is_platform_admin = bool(user.get("is_admin", 0))

        if not (is_owner or is_admin or is_platform_admin):
            raise HTTPException(403, "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e \u043f\u0440\u0430\u0432 \u0434\u043b\u044f \u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u044f \u044d\u0442\u043e\u0433\u043e \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044f")

        name = data.name.strip()
        if not name or len(name) > 100:
            raise HTTPException(422, "\u0417\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u0434\u043e\u043b\u0436\u043d\u043e \u0431\u044b\u0442\u044c \u043e\u0442 1 \u0434\u043e 100")

        description = getattr(data, "description", None)

        if description is None:
            db.execute(
                "UPDATE communities SET name=? WHERE id=?",
                (name, cid),
            )
        else:
            db.execute(
                "UPDATE communities SET name=?, description=? WHERE id=?",
                (name, description.strip(), cid),
            )

        updated = db.execute(
            "SELECT * FROM communities WHERE id=?",
            (cid,),
        ).fetchone()

        return dict(updated)

@router.delete("/api/communities/{cid}")
def delete_community(cid: int, user=Depends(current_user)):
    with get_db() as db:
        if not member(db,cid,user["id"]) or member(db,cid,user["id"])["role"] != "owner":
            raise HTTPException(403,"Удалить сообщество может только владелец")
        db.execute("DELETE FROM communities WHERE id=?",(cid,))
        return {"status":"deleted","community_id":cid}

@router.patch("/api/channels/{channel_id}")
def rename_channel(channel_id: int, data: ChannelUpdate, user=Depends(current_user)):
    with get_db() as db:
        channel = db.execute(
            "SELECT id, community_id FROM channels WHERE id=?",
            (channel_id,),
        ).fetchone()

        if channel is None:
            raise HTTPException(404, "\u041e\u0442\u0447\u0451\u0442 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d")

        community = db.execute(
            "SELECT owner_id FROM communities WHERE id=?",
            (channel["community_id"],),
        ).fetchone()

        if community is None:
            raise HTTPException(404, "\u0421\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e")

        membership = member(db, channel["community_id"], user["id"])
        role = str(membership["role"]).lower() if membership else ""

        owner_id = community["owner_id"]
        is_owner = (
            owner_id is not None and int(owner_id) == int(user["id"])
        ) or role == "owner"

        is_admin = role in ("admin", "administrator")
        is_platform_admin = bool(user.get("is_admin", 0))

        if not (is_owner or is_admin or is_platform_admin):
            raise HTTPException(403, "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e \u043f\u0440\u0430\u0432 \u0434\u043b\u044f \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f \u0443\u0447\u0430\u0441\u0442\u043d\u0438\u043a\u0430\u043c\u0438")

        name = data.name.strip()
        if len(name) < 2 or len(name) > 100:
            raise HTTPException(422, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0434\u043e\u043b\u0436\u043d\u043e \u0441\u043e\u0434\u0435\u0440\u0436\u0430\u0442\u044c \u043e\u0442 2 \u0434\u043e 100 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432")

        duplicate = db.execute(
            """
            SELECT 1 FROM channels
            WHERE community_id=? AND name=? COLLATE NOCASE AND id<>?
            """,
            (channel["community_id"], name, channel_id),
        ).fetchone()

        if duplicate:
            raise HTTPException(409, "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0443\u0436\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u043e")

        db.execute(
            "UPDATE channels SET name=? WHERE id=?",
            (name, channel_id),
        )

        updated = db.execute(
            "SELECT * FROM channels WHERE id=?",
            (channel_id,),
        ).fetchone()

        return {
            "status": "updated",
            "id": channel_id,
            "name": updated["name"],
        }

@router.delete("/api/channels/{channel_id}")
def remove_channel(channel_id: int, user=Depends(current_user)):
    with get_db() as db:
        ch = db.execute("SELECT * FROM channels WHERE id=?",(channel_id,)).fetchone()
        if not ch: raise HTTPException(404,"Канал не найден")
        if require_manager(db,ch["community_id"],user["id"]) not in ("owner","admin"):
            raise HTTPException(403,"Недостаточно прав")
        db.execute("DELETE FROM channels WHERE id=?",(channel_id,))
        return {"status":"deleted"}

@router.patch("/api/messages/{message_id}")
def edit_message(message_id: int, data: MessageUpdate, user=Depends(current_user)):
    with get_db() as db:
        msg = db.execute("SELECT * FROM messages WHERE id=?",(message_id,)).fetchone()
        if not msg: raise HTTPException(404,"Сообщение не найдено")
        require_member(db,db.execute("SELECT community_id FROM channels WHERE id=?",(msg["channel_id"],)).fetchone()["community_id"],user["id"])
        if msg["user_id"] != user["id"]:
            raise HTTPException(403,"Можно редактировать только свои сообщения")
        content=data.content.strip()
        if not content: raise HTTPException(422,"Пустое сообщение")
        db.execute("UPDATE messages SET content=?,edited_at=CURRENT_TIMESTAMP WHERE id=?",(content,message_id))
        return {"status":"updated","id":message_id,"content":content}

@router.get("/api/notifications")
def notifications(user=Depends(current_user), limit: int=Query(50,ge=1,le=100)):
    with get_db() as db:
        rows=[dict(r) for r in db.execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT ?",(user["id"],limit))]
        return {"items":rows,"unread":sum(not r["is_read"] for r in rows)}

@router.post("/api/notifications/{nid}/read")
def read_notification(nid: int, user=Depends(current_user)):
    with get_db() as db:
        cur=db.execute("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?",(nid,user["id"]))
        if not cur.rowcount: raise HTTPException(404,"Уведомление не найдено")
        return {"status":"read"}

@router.post("/api/notifications/read-all")
def read_all(user=Depends(current_user)):
    with get_db() as db:
        db.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(user["id"],))
        return {"status":"all_read"}

@router.get("/api/search")
def search(q: str=Query(min_length=2,max_length=100), user=Depends(current_user)):
    term="%"+q.strip().replace("%","\\%").replace("_","\\_")+"%"
    with get_db() as db:
        communities=[dict(r) for r in db.execute("""
          SELECT c.id,c.name,c.description,c.owner_id,
          (SELECT COUNT(*) FROM community_members m WHERE m.community_id=c.id) member_count
          FROM communities c
          WHERE c.name LIKE ? ESCAPE '\\'
            AND (
              COALESCE(c.visibility, 'public')='public'
              OR EXISTS (
                SELECT 1 FROM community_members cm
                WHERE cm.community_id=c.id AND cm.user_id=?
              )
            )
          ORDER BY c.id DESC LIMIT 20
        """,(term,user["id"]))]
        users=[dict(r) for r in db.execute("""
          SELECT id,username,display_name,avatar_url FROM users
          WHERE username LIKE ? ESCAPE '\\' OR display_name LIKE ? ESCAPE '\\' LIMIT 20
        """,(term,term))]
        messages=[dict(r) for r in db.execute("""
          SELECT m.id,m.channel_id,m.user_id,u.username,m.content,m.created_at,c.community_id
          FROM messages m JOIN users u ON u.id=m.user_id JOIN channels c ON c.id=m.channel_id
          JOIN community_members cm ON cm.community_id=c.community_id AND cm.user_id=?
          WHERE m.content LIKE ? ESCAPE '\\'
            AND (
              COALESCE(c.visibility, 'public')='public'
              OR EXISTS (
                SELECT 1 FROM channel_members chm
                WHERE chm.channel_id=c.id AND chm.user_id=?
              )
              OR EXISTS (
                SELECT 1 FROM community_members own
                WHERE own.community_id=c.community_id
                  AND own.user_id=? AND own.role='owner'
              )
            )
            ORDER BY m.id DESC LIMIT 30
        """,(user["id"],term,user["id"],user["id"]))]
        return {"communities":communities,"users":users,"messages":messages}

@router.post("/api/reports",status_code=201)
def create_report(data: ReportCreate, user=Depends(current_user)):
    if data.target_user_id is None and data.message_id is None:
        raise HTTPException(422,"Укажите пользователя или сообщение")
    with get_db() as db:
        if data.target_user_id == user["id"]:
            raise HTTPException(422,"Нельзя пожаловаться на себя")
        if data.target_user_id is not None and not db.execute("SELECT 1 FROM users WHERE id=?",(data.target_user_id,)).fetchone():
            raise HTTPException(404,"Пользователь не найден")
        if data.message_id is not None and not db.execute("SELECT 1 FROM messages WHERE id=?",(data.message_id,)).fetchone():
            raise HTTPException(404,"Сообщение не найдено")
        cur=db.execute("INSERT INTO reports(reporter_id,target_user_id,message_id,reason) VALUES(?,?,?,?)",(user["id"],data.target_user_id,data.message_id,data.reason.strip()))
        return {"id":cur.lastrowid,"status":"open"}

@router.get("/api/moderation/reports")
def list_reports(user=Depends(current_user)):
    with get_db() as db:
        if not user.get("is_admin"):
            raise HTTPException(403,"Требуется администратор платформы")
        return [dict(r) for r in db.execute("SELECT * FROM reports ORDER BY CASE status WHEN 'open' THEN 0 ELSE 1 END,id DESC LIMIT 200")]

@router.post("/api/moderation/reports/{rid}/resolve")
def resolve_report(rid: int, data: ReportResolve, user=Depends(current_user)):
    with get_db() as db:
        if not user.get("is_admin"):
            raise HTTPException(403,"Требуется администратор платформы")
        cur=db.execute("UPDATE reports SET status=?,resolution=?,moderator_id=? WHERE id=? AND status='open'",(data.status,data.resolution,user["id"],rid))
        if not cur.rowcount: raise HTTPException(404,"Открытая жалоба не найдена")
        report=db.execute("SELECT * FROM reports WHERE id=?",(rid,)).fetchone()
        notify(db, report["reporter_id"], "Жалоба рассмотрена", data.resolution)
        log_action(db,user["id"],None,report["target_user_id"],"report_"+data.status,data.resolution)
        return {"status":data.status}

@router.post("/api/moderation/users/{target}/block")
def block_user(target: int, data: BlockCreate, community_id: int | None=None, user=Depends(current_user)):
    with get_db() as db:
        if target == user["id"]: raise HTTPException(422,"Нельзя заблокировать себя")
        if not db.execute("SELECT 1 FROM users WHERE id=?",(target,)).fetchone(): raise HTTPException(404,"Пользователь не найден")
        if community_id is not None:
            actor=require_manager(db,community_id,user["id"])
            if actor not in ("owner","admin","moderator"): raise HTTPException(403,"Недостаточно прав")
            if member(db,community_id,target):
                db.execute("DELETE FROM community_members WHERE community_id=? AND user_id=?",(community_id,target))
            log_action(db,user["id"],community_id,target,"community_block",data.reason)
        else:
            if not user.get("is_admin"): raise HTTPException(403,"Для блокировки на платформе нужен администратор")
            log_action(db,user["id"],None,target,"platform_block",data.reason)
        db.execute("INSERT OR IGNORE INTO user_blocks(user_id,blocked_user_id,reason) VALUES(?,?,?)",(user["id"],target,data.reason))
        notify(db,target,"Ограничение доступа",data.reason)
        return {"status":"blocked","user_id":target}

@router.get("/api/moderation/log")
def moderation_log(community_id: int | None=None, user=Depends(current_user)):
    with get_db() as db:
        if community_id is not None:
            require_manager(db,community_id,user["id"])
            return [dict(r) for r in db.execute("SELECT * FROM moderation_log WHERE community_id=? ORDER BY id DESC LIMIT 200",(community_id,))]
        if not user.get("is_admin"): raise HTTPException(403,"Требуется администратор платформы")
        return [dict(r) for r in db.execute("SELECT * FROM moderation_log ORDER BY id DESC LIMIT 200")]

@router.post("/api/voice/{channel_id}/signal", status_code=201)
def send_voice_signal(channel_id: int, data: VoiceSignal, user=Depends(current_user)):
    import json
    try:
        payload = json.loads(data.payload)
    except Exception:
        raise HTTPException(422, "Invalid JSON payload")

    if not isinstance(payload, dict) or payload.get("type") not in ("offer", "answer", "candidate", "hangup"):
        raise HTTPException(422, "Invalid signal type")

    with get_db() as db:
        ch = db.execute(
            "SELECT * FROM channels WHERE id=? AND channel_type='voice'",
            (channel_id,),
        ).fetchone()
        if not ch:
            raise HTTPException(404, "Voice room not found")

        require_voice_channel_access(db, ch, user["id"], bool(user.get("is_admin")))
        require_voice_channel_access(db, ch, data.receiver_id)

        cur = db.execute(
            """
            INSERT INTO voice_signals(community_id,channel_id,sender_id,receiver_id,payload)
            VALUES(?,?,?,?,?)
            """,
            (ch["community_id"], channel_id, user["id"], data.receiver_id, data.payload),
        )
        return {"id": cur.lastrowid, "status": "queued", "transport": "signaling-only"}

@router.get("/api/voice/{channel_id}/signals")
def poll_voice_signals(channel_id: int, user=Depends(current_user)):
    with get_db() as db:
        ch = db.execute(
            "SELECT * FROM channels WHERE id=? AND channel_type='voice'",
            (channel_id,),
        ).fetchone()
        if not ch:
            raise HTTPException(404, "Voice room not found")

        require_voice_channel_access(db, ch, user["id"], bool(user.get("is_admin")))

        rows = [dict(r) for r in db.execute(
            "SELECT * FROM voice_signals WHERE channel_id=? AND receiver_id=? ORDER BY id LIMIT 100",
            (channel_id, user["id"]),
        )]
        if rows:
            ids = [r["id"] for r in rows]
            marks = ",".join("?" for _ in ids)
            db.execute(
                f"DELETE FROM voice_signals WHERE receiver_id=? AND id IN ({marks})",
                [user["id"], *ids],
            )
        return rows

@router.get("/api/health/features")
def feature_health():
    return {"status":"ok","features":["profiles","members_roles","community_management","channels_messages","voice_signaling","notifications","search","moderation","windows_build"],"voice_media":"requires WebRTC client and STUN/TURN configuration"}


@router.get("/api/features/communities/{cid}/members")
def feature_members(cid: int, user=Depends(current_user)):
    with get_db() as db:
        require_member(db, cid, user["id"])
        return [dict(r) for r in db.execute("""
          SELECT u.id AS user_id,u.username,u.display_name,u.avatar_url,u.status,
                 m.role,m.joined_at
          FROM community_members m JOIN users u ON u.id=m.user_id
          WHERE m.community_id=? ORDER BY m.joined_at
        """, (cid,))]



def require_voice_channel_access(db, channel, user_id: int, is_admin: bool = False):
    if channel is None or channel["channel_type"] != "voice":
        raise HTTPException(404, "Voice room not found")
    if is_admin:
        return

    membership = db.execute(
        "SELECT role FROM community_members WHERE community_id=? AND user_id=?",
        (channel["community_id"], user_id),
    ).fetchone()

    if membership is None:
        raise HTTPException(403, "Community membership required")

    if channel["visibility"] == "private" and membership["role"] != "owner":
        access = db.execute(
            "SELECT 1 FROM channel_members WHERE channel_id=? AND user_id=?",
            (channel["id"], user_id),
        ).fetchone()
        if access is None:
            raise HTTPException(403, "Private voice room access denied")


class VoiceMute(BaseModel):
    muted: bool


class VoiceChannelCreate(BaseModel):
    name: str = Field(min_length=2, max_length=50)
    visibility: str = Field(default="public", pattern="^(public|private)$")


@router.post("/api/communities/{cid}/voice-channels", status_code=201)
def create_voice_channel(cid: int, data: VoiceChannelCreate, user=Depends(current_user)):
    with get_db() as db:
        role = require_manager(db, cid, user["id"])
        if role not in ("owner", "admin"):
            raise HTTPException(403, "Only owners and admins can create voice rooms")

        name = data.name.strip()
        if not name:
            raise HTTPException(422, "Voice room name is required")

        existing = db.execute(
            "SELECT 1 FROM channels WHERE community_id=? AND name=? COLLATE NOCASE",
            (cid, name),
        ).fetchone()
        if existing:
            raise HTTPException(409, "Channel name already exists")

        cur = db.execute(
            """
            INSERT INTO channels(community_id,name,channel_type,visibility)
            VALUES(?,?,'voice',?)
            """,
            (cid, name, data.visibility),
        )
        channel_id = cur.lastrowid

        if data.visibility == "private":
            db.execute(
                "INSERT OR IGNORE INTO channel_members(channel_id,user_id) VALUES(?,?)",
                (channel_id, user["id"]),
            )

        return {
            "id": channel_id,
            "community_id": cid,
            "name": name,
            "channel_type": "voice",
            "visibility": data.visibility,
        }


@router.post("/api/voice/{channel_id}/join")
def voice_join(channel_id: int, user=Depends(current_user)):
    with get_db() as db:
        ch = db.execute(
            "SELECT * FROM channels WHERE id=? AND channel_type='voice'",
            (channel_id,),
        ).fetchone()
        if not ch:
            raise HTTPException(404, "Voice room not found")

        require_voice_channel_access(db, ch, user["id"], bool(user.get("is_admin")))

        db.execute("""
            INSERT INTO voice_presence(community_id,channel_id,user_id,muted,updated_at)
            VALUES(?,?,?,0,CURRENT_TIMESTAMP)
            ON CONFLICT(channel_id,user_id) DO UPDATE SET updated_at=CURRENT_TIMESTAMP
        """, (ch["community_id"], channel_id, user["id"]))

        return {"status": "joined", "channel_id": channel_id, "audio_transport": "not_configured"}


@router.post("/api/voice/{channel_id}/leave")
def voice_leave(channel_id: int, user=Depends(current_user)):
    with get_db() as db:
        db.execute(
            "DELETE FROM voice_presence WHERE channel_id=? AND user_id=?",
            (channel_id, user["id"])
        )
        db.execute(
            "DELETE FROM voice_signals WHERE channel_id=? AND (sender_id=? OR receiver_id=?)",
            (channel_id, user["id"], user["id"])
        )
        return {"status": "left"}


@router.get("/api/voice/{channel_id}/presence")
def voice_presence(channel_id: int, user=Depends(current_user)):
    with get_db() as db:
        ch = db.execute(
            "SELECT * FROM channels WHERE id=? AND channel_type='voice'",
            (channel_id,),
        ).fetchone()
        if not ch:
            raise HTTPException(404, "Voice room not found")

        require_voice_channel_access(db, ch, user["id"], bool(user.get("is_admin")))

        rows = db.execute("""
            SELECT p.user_id,p.muted,p.updated_at,u.username,u.display_name,u.avatar_url
            FROM voice_presence p JOIN users u ON u.id=p.user_id
            WHERE p.channel_id=? ORDER BY p.updated_at DESC
        """, (channel_id,))
        return [dict(row) for row in rows]


@router.patch("/api/voice/{channel_id}/mute")
def voice_mute(channel_id: int, data: VoiceMute, user=Depends(current_user)):
    with get_db() as db:
        ch = db.execute(
            "SELECT * FROM channels WHERE id=? AND channel_type='voice'",
            (channel_id,),
        ).fetchone()
        if not ch:
            raise HTTPException(404, "Voice room not found")

        require_voice_channel_access(db, ch, user["id"], bool(user.get("is_admin")))

        cur = db.execute("""
            UPDATE voice_presence SET muted=?,updated_at=CURRENT_TIMESTAMP
            WHERE channel_id=? AND user_id=?
        """, (int(data.muted), channel_id, user["id"]))
        if not cur.rowcount:
            raise HTTPException(409, "Join the voice room first")
        return {"status": "updated", "muted": data.muted}


# ---------------------- Friends API ----------------------

class FriendRequestCreate(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[a-zA-Z0-9_]+$")


class FriendRequestAction(BaseModel):
    action: str = Field(pattern=r"^(accept|reject)$")


@router.get("/api/friends")
def get_friends(user=Depends(current_user)):
    with get_db() as db:
        uid = user["id"]

        friends = [dict(row) for row in db.execute("""
            SELECT u.id, u.username, u.display_name, u.avatar_url, u.status
            FROM friend_requests fr
            JOIN users u ON u.id = CASE
                WHEN fr.sender_id = ? THEN fr.receiver_id
                ELSE fr.sender_id
            END
            WHERE (fr.sender_id = ? OR fr.receiver_id = ?)
              AND fr.status = 'accepted'
            ORDER BY u.username COLLATE NOCASE
        """, (uid, uid, uid))]

        incoming = [dict(row) for row in db.execute("""
            SELECT fr.id AS request_id, u.id, u.username,
                   u.display_name, u.avatar_url, u.status
            FROM friend_requests fr
            JOIN users u ON u.id = fr.sender_id
            WHERE fr.receiver_id = ? AND fr.status = 'pending'
            ORDER BY fr.id DESC
        """, (uid,))]

        outgoing = [dict(row) for row in db.execute("""
            SELECT fr.id AS request_id, u.id, u.username,
                   u.display_name, u.avatar_url, u.status
            FROM friend_requests fr
            JOIN users u ON u.id = fr.receiver_id
            WHERE fr.sender_id = ? AND fr.status = 'pending'
            ORDER BY fr.id DESC
        """, (uid,))]

        return {"friends": friends, "incoming": incoming, "outgoing": outgoing}


@router.post("/api/friends/requests", status_code=201)
def create_friend_request(data: FriendRequestCreate, user=Depends(current_user)):
    with get_db() as db:
        target = db.execute(
            "SELECT id, username FROM users WHERE username = ? COLLATE NOCASE",
            (data.username.strip(),),
        ).fetchone()

        if target is None:
            raise HTTPException(404, "Пользователь не найден")
        if target["id"] == user["id"]:
            raise HTTPException(400, "Нельзя добавить самого себя")

        sender_id = user["id"]
        receiver_id = target["id"]

        accepted = db.execute("""
            SELECT id FROM friend_requests
            WHERE status = 'accepted'
              AND ((sender_id = ? AND receiver_id = ?)
                OR (sender_id = ? AND receiver_id = ?))
            LIMIT 1
        """, (sender_id, receiver_id, receiver_id, sender_id)).fetchone()

        if accepted:
            return {"status": "already_friends", "username": target["username"]}

        reverse = db.execute("""
            SELECT id, status FROM friend_requests
            WHERE sender_id = ? AND receiver_id = ?
        """, (receiver_id, sender_id)).fetchone()

        if reverse and reverse["status"] == "pending":
            db.execute("""
                UPDATE friend_requests
                SET status = 'accepted', updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (reverse["id"],))
            return {"status": "accepted", "username": target["username"]}

        existing = db.execute("""
            SELECT id, status FROM friend_requests
            WHERE sender_id = ? AND receiver_id = ?
        """, (sender_id, receiver_id)).fetchone()

        if existing and existing["status"] == "pending":
            return {"status": "already_pending", "username": target["username"]}

        if existing:
            db.execute("""
                UPDATE friend_requests
                SET status = 'pending', updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (existing["id"],))
        else:
            db.execute("""
                INSERT INTO friend_requests(sender_id, receiver_id, status)
                VALUES (?, ?, 'pending')
            """, (sender_id, receiver_id))

        return {"status": "pending", "username": target["username"]}


@router.patch("/api/friends/requests/{request_id}")
def respond_friend_request(
    request_id: int,
    data: FriendRequestAction,
    user=Depends(current_user),
):
    with get_db() as db:
        request = db.execute("""
            SELECT id, sender_id, receiver_id, status
            FROM friend_requests WHERE id = ?
        """, (request_id,)).fetchone()

        if request is None:
            raise HTTPException(404, "Запрос дружбы не найден")
        if request["receiver_id"] != user["id"]:
            raise HTTPException(403, "Можно отвечать только на входящие запросы")
        if request["status"] != "pending":
            raise HTTPException(409, "Запрос уже обработан")

        status = "accepted" if data.action == "accept" else "rejected"
        db.execute("""
            UPDATE friend_requests
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (status, request_id))

        return {"status": status, "request_id": request_id}


@router.delete("/api/friends/{friend_id}")
def remove_friend(friend_id: int, user=Depends(current_user)):
    with get_db() as db:
        cur = db.execute("""
            DELETE FROM friend_requests
            WHERE status = 'accepted'
              AND ((sender_id = ? AND receiver_id = ?)
                OR (sender_id = ? AND receiver_id = ?))
        """, (user["id"], friend_id, friend_id, user["id"]))

        if not cur.rowcount:
            raise HTTPException(404, "Друг не найден")

        return {"status": "removed", "friend_id": friend_id}


@router.delete("/api/friends/requests/{request_id}")
def cancel_friend_request(request_id: int, user=Depends(current_user)):
    with get_db() as db:
        row = db.execute("""
            SELECT id FROM friend_requests
            WHERE id=? AND sender_id=? AND status='pending'
        """, (request_id, user["id"])).fetchone()

        if row is None:
            raise HTTPException(404, "Исходящий запрос не найден или уже обработан")

        db.execute("DELETE FROM friend_requests WHERE id=?", (request_id,))
        return {"status": "cancelled", "request_id": request_id}


# ---------------------- COMMUNITY INVITATIONS ----------------------

class CommunityInvitationCreate(BaseModel):
    invitee_id: int = Field(gt=0)


class CommunityInvitationAction(BaseModel):
    action: str = Field(pattern="^(accept|reject)$")


@router.get("/api/community-invitations/incoming")
def get_incoming_community_invitations(user=Depends(current_user)):
    with get_db() as db:
        rows = db.execute("""
            SELECT
                i.id AS invitation_id,
                i.community_id,
                i.created_at,
                c.name AS community_name,
                c.visibility,
                u.id AS inviter_id,
                u.username AS inviter_username,
                u.display_name AS inviter_display_name,
                u.avatar_url AS inviter_avatar_url
            FROM community_invitations i
            JOIN communities c ON c.id=i.community_id
            JOIN users u ON u.id=i.inviter_id
            WHERE i.invitee_id=? AND i.status='pending'
            ORDER BY i.id DESC
        """, (user["id"],)).fetchall()

        return [dict(row) for row in rows]


@router.post("/api/communities/{community_id}/invitations", status_code=201)
def invite_friend_to_community(
    community_id: int,
    data: CommunityInvitationCreate,
    user=Depends(current_user),
):
    inviter_id = int(user["id"])
    invitee_id = int(data.invitee_id)

    if inviter_id == invitee_id:
        raise HTTPException(400, "\u041d\u0435\u043b\u044c\u0437\u044f \u043f\u0440\u0438\u0433\u043b\u0430\u0441\u0438\u0442\u044c \u0441\u0430\u043c\u043e\u0433\u043e \u0441\u0435\u0431\u044f")

    with get_db() as db:
        community = db.execute(
            "SELECT id, name FROM communities WHERE id=?",
            (community_id,),
        ).fetchone()

        if community is None:
            raise HTTPException(404, "\u0421\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e")

        inviter_membership = db.execute(
            """
            SELECT 1 FROM community_members
            WHERE community_id=? AND user_id=?
            """,
            (community_id, inviter_id),
        ).fetchone()

        if not inviter_membership:
            raise HTTPException(403, "\u0414\u043b\u044f \u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u044f \u043d\u0443\u0436\u043d\u043e \u0441\u043e\u0441\u0442\u043e\u044f\u0442\u044c \u0432 \u0441\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u0435")

        friendship = db.execute("""
            SELECT id FROM friend_requests
            WHERE status='accepted'
              AND (
                (sender_id=? AND receiver_id=?)
                OR
                (sender_id=? AND receiver_id=?)
              )
            LIMIT 1
        """, (inviter_id, invitee_id, invitee_id, inviter_id)).fetchone()

        if friendship is None:
            raise HTTPException(403, "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0430\u0442\u044c \u043c\u043e\u0436\u043d\u043e \u0442\u043e\u043b\u044c\u043a\u043e \u0434\u0440\u0443\u0437\u0435\u0439")

        target = db.execute(
            "SELECT id FROM users WHERE id=?",
            (invitee_id,),
        ).fetchone()

        if target is None:
            raise HTTPException(404, "\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d")

        membership = db.execute(
            """
            SELECT 1 FROM community_members
            WHERE community_id=? AND user_id=?
            """,
            (community_id, invitee_id),
        ).fetchone()

        if membership:
            raise HTTPException(409, "\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c \u0443\u0436\u0435 \u0441\u043e\u0441\u0442\u043e\u0438\u0442 \u0432 \u0441\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u0435")

        existing = db.execute("""
            SELECT id FROM community_invitations
            WHERE community_id=? AND invitee_id=? AND status='pending'
        """, (community_id, invitee_id)).fetchone()

        if existing:
            return {
                "status": "already_pending",
                "invitation_id": existing["id"],
            }

        cursor = db.execute("""
            INSERT INTO community_invitations
                (community_id, inviter_id, invitee_id)
            VALUES (?, ?, ?)
        """, (community_id, inviter_id, invitee_id))

        invitation_id = cursor.lastrowid

        notify(
            db,
            invitee_id,
            "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u0432 \u0441\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u043e",
            f"\u0412\u0430\u0441 \u043f\u0440\u0438\u0433\u043b\u0430\u0441\u0438\u043b\u0438 \u0432 \u0441\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u043e \u00ab{community['name']}\u00bb",
        )

        return {
            "status": "pending",
            "invitation_id": invitation_id,
            "community_id": community_id,
        }


@router.patch("/api/community-invitations/{invitation_id}")
def answer_community_invitation(
    invitation_id: int,
    data: CommunityInvitationAction,
    user=Depends(current_user),
):
    with get_db() as db:
        invitation = db.execute("""
            SELECT id, community_id, inviter_id, invitee_id, status
            FROM community_invitations
            WHERE id=?
        """, (invitation_id,)).fetchone()

        if invitation is None:
            raise HTTPException(404, "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e")

        if int(invitation["invitee_id"]) != int(user["id"]):
            raise HTTPException(403, "\u042d\u0442\u043e \u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u0430\u0434\u0440\u0435\u0441\u043e\u0432\u0430\u043d\u043e \u0434\u0440\u0443\u0433\u043e\u043c\u0443 \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044e")

        if invitation["status"] != "pending":
            raise HTTPException(409, "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u0443\u0436\u0435 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u0430\u043d\u043e")

        community = db.execute(
            "SELECT id, name FROM communities WHERE id=?",
            (invitation["community_id"],),
        ).fetchone()

        if community is None:
            raise HTTPException(404, "\u0421\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u043e \u0431\u043e\u043b\u044c\u0448\u0435 \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442")

        if data.action == "accept":
            db.execute("""
                INSERT OR IGNORE INTO community_members
                    (community_id, user_id, role)
                VALUES (?, ?, 'member')
            """, (invitation["community_id"], user["id"]))

            status = "accepted"

            notify(
                db,
                invitation["inviter_id"],
                "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u043d\u044f\u0442\u043e",
                f"\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c \u043f\u0440\u0438\u043d\u044f\u043b \u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u0432 \u00ab{community['name']}\u00bb",
            )
        else:
            status = "rejected"

            notify(
                db,
                invitation["inviter_id"],
                "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u043e\u0442\u043a\u043b\u043e\u043d\u0435\u043d\u043e",
                f"\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c \u043e\u0442\u043a\u043b\u043e\u043d\u0438\u043b \u043f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u0432 \u00ab{community['name']}\u00bb",
            )

        updated = db.execute("""
            UPDATE community_invitations
            SET status=?, responded_at=CURRENT_TIMESTAMP
            WHERE id=? AND status='pending'
        """, (status, invitation_id))

        if updated.rowcount != 1:
            raise HTTPException(409, "\u041f\u0440\u0438\u0433\u043b\u0430\u0448\u0435\u043d\u0438\u0435 \u0443\u0436\u0435 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u0430\u043d\u043e")

        return {
            "status": status,
            "invitation_id": invitation_id,
            "community_id": invitation["community_id"],
        }

